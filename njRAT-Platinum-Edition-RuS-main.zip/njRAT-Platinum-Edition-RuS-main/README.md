# njRAT-Platinum-Edition-RuS

+added new sound alert (you spin me right round)

+added greeting at the entrance

+everything is translated into Russian


----------------------------------------
![IMG_20230729_181602](https://github.com/JumperYT-official/njRAT-Platinum-Edition-RuS/assets/140055242/368eb147-85a9-462c-bf3d-66eedb31cef5)
